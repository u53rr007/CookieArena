#!/bin/bash
docker rm -f fundamental-001
docker build --tag=fundamental-001 .
docker run -p 1337:1337 --rm --name=fundamental-001 fundamental-001